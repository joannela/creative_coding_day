AT407 Tilt Sensor
=======================

![AT407 Tilt Sensor](https://cdn.sparkfun.com//assets/parts/4/6/8/5/10289-01.jpg)

[*AT407 Tilt Sensor (SEN-10289)*](https://www.sparkfun.com/products/10289)


Repository Contents
-------------------
* **/Firmware** - Example Arduino code. 

License Information
-------------------
The code is beerware; if you see me (or any other SparkFun employee) at the local, and you've found our code helpful, please buy us a round!

Distributed as-is; no warranty is given.
